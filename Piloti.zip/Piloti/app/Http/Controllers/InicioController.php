<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Usuario;
use App\UsuarioDeletado;

class InicioController extends Controller
{
    public function index(){
      return view('inicio');
    }

    public function registrar(){
      return view('cadastro');
    }

    public function entrar(){
      return view('login');
    }

    public function admin(){
      $usuarios = Usuario::all();
      return view('admin',compact('usuarios'));
    }

    public function deletados(){
      $usuarios = UsuarioDeletado::all();
      return view('deletados',compact('usuarios'));
    }
}
