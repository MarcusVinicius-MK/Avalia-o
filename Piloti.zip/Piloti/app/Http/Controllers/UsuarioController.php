<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Usuario;
use App\UsuarioDeletado;
use Auth;

class UsuarioController extends Controller
{

    public function adicionar(Request $req){
      $dados = $req->all();
      $usuario = Usuario::create($dados);
      return redirect()->route('alterar',$usuario['id']);
    }

    public function confirmar(Request $req){
      $dados = $req->all();
      $verifica = Usuario::where('nome','=',$dados['nome'])->first();
      if($verifica['nome'] == $dados['nome'] && $verifica['senha'] == $dados['senha']){
        if($verifica['funcao'] == 'admin'){
          return redirect()->route('admin');
        }else{
          return redirect()->route('alterar',$verifica['id']);
        }
      }else{
        return redirect()->route('inicio');
      }
    }

    public function alterar($id){
      $usuario = Usuario::find($id);
      return view('usuario',compact('usuario'));
    }

    public function editar(Request $req, $id){
      $dados = $req->all();
      Usuario::find($id)->update($dados);
      return redirect()->route('inicio');
    }

    public function excluir($id)
    {
      $dados = (object) Usuario::find($id);

      $del = new UsuarioDeletado;
      $del->id = $dados['id'];
      $del->nome = $dados['nome'];
      $del->senha = $dados['senha'];
      $del->email = $dados['email'];
      $del->funcao = $dados['funcao'];
      $del->save();

      Usuario::find($id)->delete();

      return redirect()->route('admin');
    }

}
