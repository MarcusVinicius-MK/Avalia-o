<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsuarioDeletadosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('usuario_deletados', function (Blueprint $table) {
          $table->integer('id');
          $table->string('nome');
          $table->string('email');
          $table->string('senha');
          $table->enum('funcao',['admin','user'])->default('user');
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('usuario_deletados');
    }
}
