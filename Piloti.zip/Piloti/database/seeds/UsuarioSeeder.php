<?php

use Illuminate\Database\Seeder;
use App\Usuario;

class UsuarioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $dados = [
          'nome'=>'admin',
          'email'=>'admin@mail.com',
          'senha'=>'admin123',
          'funcao'=>'admin',
        ];
        if(Usuario::where('nome','=',$dados['email'])->count()){
          $usuario = Usuario::where('nome','=',$dados['email'])->first();
          $usuario->update($dados);
        }else{
          Usuario::create($dados);
        }
    }
}
