@extends('layout.site')
@section('titulo','Admin')
@section('conteudo')
  <div class="row">
    <div class="col-sm-12">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Nome</th>
            <th scope="col">Email</th>
            <th scope="col">Função</th>
            <th scope="col"></th>
          </tr>
        </thead>
        <tbody>
          @foreach($usuarios as $usuario)
            <tr>
              <td scope="col">{{$usuario->id}}</td>
              <td>{{$usuario->nome}}</td>
              <td>{{$usuario->email}}</td>
              <td>{{$usuario->funcao}}</td>
              <td>
                <a href="{{route('alterar',$usuario->id)}}">Alterar</a>
                <a href="{{route('excluir',$usuario->id)}}">Excluir</a>
              </td>
            </tr>
          @endforeach
        </tbody>
      </table>
      <br>
      <a href="{{route('admin.deletados')}}">Ver usuários excluídos</a>
    </div>
  </div>
@endsection
