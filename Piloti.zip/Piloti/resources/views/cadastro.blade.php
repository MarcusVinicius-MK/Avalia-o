@extends('layout.site')
@section('titulo','Registrar')
@section('conteudo')
  <div class="row">
    <div class="col-sm-12">
      <form method="post" action="{{route('registrar.adicionar')}}">
        {{csrf_field()}}
        <div class="form-group">
          <label for="idNome">Nome
            <input type="text" class="form-control" id="idNome" name="nome">
          </label>
        </div>
        <div class="form-group">
          <label for="idEmail">Email
            <input type="email" class="form-control" id="idEmail" name="email">
          </label>
        </div>
        <div class="form-group">
          <label for="idSenha">Senha
            <input type="password" class="form-control" id="idSenha" name="senha">
          </label>
        </div>
        <button type="submit" class="btn btn-primary">Registrar</button>
      </form>
    </div>
  </div>
@endsection
