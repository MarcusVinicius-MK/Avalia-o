@extends('layout.site')
@section('titulo','Admin')
@section('conteudo')
  <div class="row">
    <div class="col-sm-12">
      <table class="table">
        <thead>
          <tr>
            <th scope="col" colspan="4">Usuários Excluidos</th>
          </tr>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Nome</th>
            <th scope="col">Email</th>
            <th scope="col">Função</th>
          </tr>
        </thead>
        <tbody>
          @foreach($usuarios as $usuario)
            <tr>
              <td scope="col">{{$usuario->id}}</td>
              <td>{{$usuario->nome}}</td>
              <td>{{$usuario->email}}</td>
              <td>{{$usuario->funcao}}</td>
            </tr>
          @endforeach
        </tbody>
      </table>
      <br>
      <a href="{{route('admin')}}">Ver usuários cadastrados</a>
    </div>
  </div>
@endsection
