@extends('layout.site')
@section('titulo','Home')
@section('conteudo')
  <div class="row">
    <div class="col-sm-12">
      <h2 align="center">Bem Vindo!</h2>
    </div>
  </div>
@endsection
