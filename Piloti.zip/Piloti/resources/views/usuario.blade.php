@extends('layout.site')
@section('titulo','Pessoal')
@section('conteudo')
  <div class="row">
    <div class="col-sm-12">
      <h2>Dados de {{$usuario->nome}}</h2>
      <form method="post" action="{{route('alterar.editar',$usuario->id)}}">
        {{csrf_field()}}
        <input type="hidden" name="idPK" value="{{$usuario->id}}">
        <div class="form-group">
          <label for="idNome">Nome
            <input type="text" class="form-control" id="idNome" name="nome" value="{{$usuario->nome}}">
          </label>
        </div>
        <div class="form-group">
          <label for="idEmail">Email
            <input type="email" class="form-control" id="idEmail" name="email" value="{{$usuario->email}}">
          </label>
        </div>
        <button type="submit" class="btn btn-primary">Alterar</button>
      </form>
    </div>
  </div>
@endsection
