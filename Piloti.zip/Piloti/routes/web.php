<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/


Route::get('/admin', ['as' => 'admin','uses'=>'InicioController@admin']);
Route::get('/admin/deletados', ['as' => 'admin.deletados','uses'=>'InicioController@deletados']);
Route::get('/admin/excluir/{id}', [ 'as'=>'excluir','uses'=>'UsuarioController@excluir']);
Route::get('/alterar/{id}', [ 'as'=>'alterar','uses'=>'UsuarioController@alterar']);
Route::post('/alterar/editar/{id}', [ 'as'=>'alterar.editar','uses'=>'UsuarioController@editar']);


Route::get('/', [ 'as'=>'inicio','uses'=>'InicioController@index']);
Route::get('/entrar', [ 'as'=>'entrar','uses'=>'InicioController@entrar']);
Route::post('/entrar/confirmar', [ 'as'=>'entrar.confirmar','uses'=>'UsuarioController@confirmar']);
Route::get('/registrar', [ 'as'=>'registrar','uses'=>'InicioController@registrar']);
Route::post('/registrar/adicionar', [ 'as'=>'registrar.adicionar','uses'=>'UsuarioController@adicionar']);
