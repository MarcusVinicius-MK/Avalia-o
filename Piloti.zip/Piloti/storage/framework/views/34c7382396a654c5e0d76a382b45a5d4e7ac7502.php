<?php $__env->startSection('titulo','Home'); ?>
<?php $__env->startSection('conteudo'); ?>
  <div class="row">
    <div class="col-sm-12">
      <h2 align="center">Bem Vindo!</h2>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>