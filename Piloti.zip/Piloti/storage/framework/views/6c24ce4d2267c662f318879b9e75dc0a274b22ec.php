<?php $__env->startSection('titulo','Admin'); ?>
<?php $__env->startSection('conteudo'); ?>
  <div class="row">
    <div class="col-sm-12">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Nome</th>
            <th scope="col">Email</th>
            <th scope="col">Função</th>
            <th scope="col"></th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
              <td scope="col"><?php echo e($usuario->id); ?></td>
              <td><?php echo e($usuario->nome); ?></td>
              <td><?php echo e($usuario->email); ?></td>
              <td><?php echo e($usuario->funcao); ?></td>
              <td>
                <a href="<?php echo e(route('alterar',$usuario->id)); ?>">Alterar</a>
                <a href="<?php echo e(route('excluir',$usuario->id)); ?>">Excluir</a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>
      </table>
      <br>
      <a href="<?php echo e(route('admin.deletados')); ?>">Ver usuários excluídos</a>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>