<?php $__env->startSection('titulo','Registrar'); ?>
<?php $__env->startSection('conteudo'); ?>
  <div class="row">
    <div class="col-sm-12">
      <form method="post" action="<?php echo e(route('registrar.adicionar')); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
          <label for="idNome">Nome
            <input type="text" class="form-control" id="idNome" name="nome">
          </label>
        </div>
        <div class="form-group">
          <label for="idEmail">Email
            <input type="email" class="form-control" id="idEmail" name="email">
          </label>
        </div>
        <div class="form-group">
          <label for="idSenha">Senha
            <input type="password" class="form-control" id="idSenha" name="senha">
          </label>
        </div>
        <button type="submit" class="btn btn-primary">Registrar</button>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>